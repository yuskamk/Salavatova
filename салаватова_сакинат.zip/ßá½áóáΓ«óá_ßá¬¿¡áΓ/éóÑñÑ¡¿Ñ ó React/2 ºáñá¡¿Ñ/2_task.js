import React, { useState, useEffect, useCallback } from 'react';

const AnalyticsDashboard = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [dateRange, setDateRange] = useState('week');
  const [selectedMetric, setSelectedMetric] = useState('revenue');

  const metrics = {
    revenue: { label: 'Revenue', color: '#4CAF50' },
    users: { label: 'Users', color: '#2196F3' },
    conversions: { label: 'Conversions', color: '#FF9800' }
  };

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Имитация API запроса
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const mockData = {
        revenue: [12000, 19000, 15000, 25000, 22000, 30000, 28000],
        users: [150, 220, 180, 300, 280, 350, 320],
        conversions: [45, 60, 55, 75, 70, 85, 80],
        summary: {
          totalRevenue: 151000,
          totalUsers: 1800,
          conversionRate: 4.2,
          growth: 12.5
        }
      };
      
      setData(mockData);
    } catch (err) {
      setError('Failed to fetch data');
    } finally {
      setLoading(false);
    }
  }, [dateRange]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const renderChart = () => {
    if (!data) return null;
    
    const chartData = data[selectedMetric];
    const maxValue = Math.max(...chartData);
    
    return (
      <div className="chart-container">
        <div className="chart">
          {chartData.map((value, index) => (
            <div key={index} className="chart-bar-container">
              <div
                className="chart-bar"
                style={{
                  height: `${(value / maxValue) * 100}%`,
                  backgroundColor: metrics[selectedMetric].color
                }}
              />
              <span className="chart-label">{value}</span>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderSummaryCards = () => {
    if (!data) return null;
    
    return (
      <div className="summary-cards">
        <div className="summary-card">
          <h3>Total Revenue</h3>
          <p className="value">${data.summary.totalRevenue.toLocaleString()}</p>
        </div>
        <div className="summary-card">
          <h3>Total Users</h3>
          <p className="value">{data.summary.totalUsers.toLocaleString()}</p>
        </div>
        <div className="summary-card">
          <h3>Conversion Rate</h3>
          <p className="value">{data.summary.conversionRate}%</p>
        </div>
        <div className="summary-card">
          <h3>Growth</h3>
          <p className="value positive">+{data.summary.growth}%</p>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="dashboard-loading">
        <div className="spinner"></div>
        <p>Loading analytics data...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="dashboard-error">
        <p>{error}</p>
        <button onClick={fetchData}>Retry</button>
      </div>
    );
  }

  return (
    <div className="analytics-dashboard">
      <header className="dashboard-header">
        <h1>Analytics Dashboard</h1>
        <div className="dashboard-controls">
          <select 
            value={dateRange} 
            onChange={(e) => setDateRange(e.target.value)}
          >
            <option value="day">Today</option>
            <option value="week">Last Week</option>
            <option value="month">Last Month</option>
            <option value="year">Last Year</option>
          </select>
          <div className="metric-selector">
            {Object.keys(metrics).map(metric => (
              <button
                key={metric}
                className={`metric-btn ${selectedMetric === metric ? 'active' : ''}`}
                onClick={() => setSelectedMetric(metric)}
                style={{
                  borderColor: metrics[metric].color
                }}
              >
                {metrics[metric].label}
              </button>
            ))}
          </div>
        </div>
      </header>

      {renderSummaryCards()}

      <div className="chart-section">
        <h2>{metrics[selectedMetric].label} Overview</h2>
        {renderChart()}
      </div>

      <div className="recent-activity">
        <h2>Recent Activity</h2>
        <div className="activity-list">
          <div className="activity-item">
            <span className="activity-badge new">New</span>
            <span>50 new users registered</span>
            <span className="activity-time">2 hours ago</span>
          </div>
          <div className="activity-item">
            <span className="activity-badge sale">Sale</span>
            <span>New high-value conversion</span>
            <span className="activity-time">5 hours ago</span>
          </div>
          <div className="activity-item">
            <span className="activity-badge update">Update</span>
            <span>System performance improved</span>
            <span className="activity-time">1 day ago</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsDashboard;