import React, { useState, useEffect } from 'react';

const AdvancedTodoApp = () => {
  const [todos, setTodos] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('date');
  const [language, setLanguage] = useState('ru');

  const translations = {
    ru: {
      title: 'Менеджер задач',
      placeholder: 'Добавить новую задачу...',
      searchPlaceholder: 'Поиск задач...',
      all: 'Все',
      active: 'Активные',
      completed: 'Завершенные',
      add: 'Добавить',
      delete: 'Удалить',
      empty: 'Нет задач',
      priority: 'Приоритет',
      high: 'Высокий',
      medium: 'Средний',
      low: 'Низкий'
    },
    en: {
      title: 'Task Manager',
      placeholder: 'Add new task...',
      searchPlaceholder: 'Search tasks...',
      all: 'All',
      active: 'Active',
      completed: 'Completed',
      add: 'Add',
      delete: 'Delete',
      empty: 'No tasks',
      priority: 'Priority',
      high: 'High',
      medium: 'Medium',
      low: 'Low'
    }
  };

  useEffect(() => {
    const saved = localStorage.getItem('advancedTodos');
    if (saved) setTodos(JSON.parse(saved));
  }, []);

  useEffect(() => {
    localStorage.setItem('advancedTodos', JSON.stringify(todos));
  }, [todos]);

  const addTodo = () => {
    if (inputValue.trim()) {
      const newTodo = {
        id: Date.now(),
        text: inputValue,
        completed: false,
        priority: 'medium',
        createdAt: new Date().toISOString()
      };
      setTodos([...todos, newTodo]);
      setInputValue('');
    }
  };

  const toggleTodo = (id) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    ));
  };

  const deleteTodo = (id) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  const updatePriority = (id, priority) => {
    setTodos(todos.map(todo =>
      todo.id === id ? { ...todo, priority } : todo
    ));
  };

  const filteredAndSortedTodos = todos
    .filter(todo => {
      const matchesSearch = todo.text.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesFilter = filter === 'all' || 
        (filter === 'active' && !todo.completed) || 
        (filter === 'completed' && todo.completed);
      return matchesSearch && matchesFilter;
    })
    .sort((a, b) => {
      if (sortBy === 'date') return new Date(b.createdAt) - new Date(a.createdAt);
      if (sortBy === 'priority') {
        const priorityOrder = { high: 3, medium: 2, low: 1 };
        return priorityOrder[b.priority] - priorityOrder[a.priority];
      }
      return 0;
    });

  const t = translations[language];

  return (
    <div className="advanced-todo">
      <div className="todo-header">
        <h1>{t.title}</h1>
        <select value={language} onChange={(e) => setLanguage(e.target.value)}>
          <option value="ru">Русский</option>
          <option value="en">English</option>
        </select>
      </div>

      <div className="todo-controls">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder={t.placeholder}
          onKeyPress={(e) => e.key === 'Enter' && addTodo()}
        />
        <button onClick={addTodo}>{t.add}</button>
      </div>

      <div className="filters">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder={t.searchPlaceholder}
        />
        <select value={filter} onChange={(e) => setFilter(e.target.value)}>
          <option value="all">{t.all}</option>
          <option value="active">{t.active}</option>
          <option value="completed">{t.completed}</option>
        </select>
        <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
          <option value="date">{language === 'ru' ? 'По дате' : 'By Date'}</option>
          <option value="priority">{t.priority}</option>
        </select>
      </div>

      <div className="todo-list">
        {filteredAndSortedTodos.length === 0 ? (
          <p>{t.empty}</p>
        ) : (
          filteredAndSortedTodos.map(todo => (
            <div key={todo.id} className={`todo-item ${todo.completed ? 'completed' : ''}`}>
              <input
                type="checkbox"
                checked={todo.completed}
                onChange={() => toggleTodo(todo.id)}
              />
              <span className="todo-text">{todo.text}</span>
              <select
                value={todo.priority}
                onChange={(e) => updatePriority(todo.id, e.target.value)}
                className={`priority-${todo.priority}`}
              >
                <option value="low">{t.low}</option>
                <option value="medium">{t.medium}</option>
                <option value="high">{t.high}</option>
              </select>
              <button onClick={() => deleteTodo(todo.id)}>{t.delete}</button>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AdvancedTodoApp;