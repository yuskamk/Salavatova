class AdvancedPromise {
    // Повторные попытки с экспоненциальной задержкой
    static retry(promiseFn, maxAttempts = 3, delay = 1000) {
        return new Promise(async (resolve, reject) => {
            let lastError;
            
            for (let attempt = 1; attempt <= maxAttempts; attempt++) {
                try {
                    console.log(`Попытка ${attempt} из ${maxAttempts}`);
                    const result = await promiseFn();
                    resolve(result);
                    return; // Успех - выходим из функции
                } catch (error) {
                    lastError = error;
                    console.log(`Попытка ${attempt} не удалась:`, error.message);
                    
                    if (attempt === maxAttempts) {
                        break; // Последняя попытка - не ждем
                    }
                    
                    // Экспоненциальная задержка
                    const currentDelay = delay * Math.pow(2, attempt - 1);
                    console.log(`Ждем ${currentDelay}ms перед следующей попыткой`);
                    await new Promise(resolve => setTimeout(resolve, currentDelay));
                }
            }
            
            reject(lastError); // Все попытки исчерпаны
        });
    }

    // Таймаут для промиса
    static timeout(promise, ms) {
        return new Promise(async (resolve, reject) => {
            const timeoutId = setTimeout(() => {
                reject(new Error(`Таймаут: операция не завершена за ${ms}ms`));
            }, ms);
            
            try {
                const result = await promise;
                clearTimeout(timeoutId);
                resolve(result);
            } catch (error) {
                clearTimeout(timeoutId);
                reject(error);
            }
        });
    }

    // Очередь с ограничением параллелизма
    static async queue(tasks, concurrency = 1) {
        const results = [];
        const running = [];
        
        // Функция для выполнения задачи
        async function runTask(task, index) {
            try {
                const result = await task();
                results[index] = { status: 'fulfilled', value: result };
            } catch (error) {
                results[index] = { status: 'rejected', reason: error };
            }
        }
        
        // Запуск задач с ограничением параллелизма
        for (let i = 0; i < tasks.length; i++) {
            const task = tasks[i];
            const taskPromise = runTask(task, i);
            running.push(taskPromise);
            
            if (running.length >= concurrency) {
                await Promise.race(running);
                // Удаляем завершенные задачи
                for (let j = 0; j < running.length; j++) {
                    if (running[j].status === 'fulfilled' || running[j].status === 'rejected') {
                        running.splice(j, 1);
                        j--;
                    }
                }
            }
        }
        
        // Ждем завершения всех оставшихся задач
        await Promise.all(running);
        return results;
    }
}

// Пример использования
AdvancedPromise.retry(
    () => fetch("https://jsonplaceholder.typicode.com/posts/1"),
    3,
    1000
)
.then(response => response.json())
.then(console.log)
.catch(console.error);