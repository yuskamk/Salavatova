class DataProcessor {
    constructor() {
        this.isPaused = false;
        this.pauseResume = null;
    }
    
    async pause() {
        this.isPaused = true;
        if (!this.pauseResume) {
            this.pauseResume = new Promise(resolve => {
                this.resume = resolve;
            });
        }
        await this.pauseResume;
    }
    
    resumeProcessing() {
        if (this.isPaused && this.resume) {
            this.isPaused = false;
            this.resume();
            this.pauseResume = null;
        }
    }
}

async function processDataAsync(data, processorFn, options = {}) {
    const {
        concurrency = 1,
        retryAttempts = 0,
        onProgress = null
    } = options;
    
    const processor = new DataProcessor();
    const results = [];
    const stats = {
        successful: 0,
        failed: 0,
        total: data.length,
        processed: 0
    };
    
    // Функция для обработки одного элемента с повторными попытками
    async function processItem(item, index) {
        let lastError;
        
        for (let attempt = 1; attempt <= retryAttempts + 1; attempt++) {
            // Проверка паузы
            if (processor.isPaused) {
                await processor.pauseResume;
            }
            
            try {
                const result = await processorFn(item, index);
                results[index] = { status: 'success', data: result, attempts: attempt };
                stats.successful++;
                return;
            } catch (error) {
                lastError = error;
                
                if (attempt <= retryAttempts) {
                    console.log(`Повторная попытка ${attempt} для элемента ${item}`);
                    // Экспоненциальная задержка между попытками
                    await new Promise(resolve => setTimeout(resolve, 100 * Math.pow(2, attempt - 1)));
                }
            }
        }
        
        results[index] = { status: 'error', error: lastError, attempts: retryAttempts + 1 };
        stats.failed++;
    }
    
    // Обработка с ограничением параллелизма
    const running = [];
    
    for (let i = 0; i < data.length; i++) {
        const item = data[i];
        const taskPromise = processItem(item, i);
        running.push(taskPromise);
        
        // Обновление прогресса
        taskPromise.finally(() => {
            stats.processed++;
            if (onProgress) {
                onProgress({ ...stats });
            }
        });
        
        if (running.length >= concurrency) {
            await Promise.race(running);
            // Очистка завершенных задач
            for (let j = 0; j < running.length; j++) {
                if (running[j].status === 'fulfilled' || running[j].status === 'rejected') {
                    running.splice(j, 1);
                    j--;
                }
            }
        }
    }
    
    // Ожидание завершения всех задач
    await Promise.all(running);
    
    return {
        results,
        stats,
        processor // Возвращаем processor для контроля паузы/возобновления
    };
}

// Пример использования
const results = await processDataAsync(
    [1, 2, 3, 4, 5, 6, 7, 8],
    async (num) => {
        await new Promise(resolve => setTimeout(resolve, 100));
        if (num === 3) {
            throw new Error('Искусственная ошибка для теста');
        }
        return num * 2;
    },
    { 
        concurrency: 2, 
        retryAttempts: 2,
        onProgress: (stats) => {
            console.log(`Прогресс: ${stats.processed}/${stats.total}`);
        }
    }
);

console.log('Результаты обработки:', results);