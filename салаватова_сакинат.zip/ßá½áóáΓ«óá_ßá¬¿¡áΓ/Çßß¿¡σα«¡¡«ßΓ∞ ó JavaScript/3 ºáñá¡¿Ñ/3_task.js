class AsyncPipeline {
    constructor() {
        this.steps = [];
    }
    
    // Добавление шага в пайплайн
    addStep(stepFn) {
        this.steps.push(stepFn);
        return this; // Для чейнинга
    }
    
    // Последовательное выполнение шагов
    async execute(input) {
        let result = input;
        
        for (let i = 0; i < this.steps.length; i++) {
            const step = this.steps[i];
            try {
                console.log(`Выполнение шага ${i + 1} из ${this.steps.length}`);
                result = await step(result);
                console.log(`Результат после шага ${i + 1}:`, result);
            } catch (error) {
                console.error(`Ошибка на шаге ${i + 1}:`, error);
                throw new Error(`Пайплайн прерван на шаге ${i + 1}: ${error.message}`);
            }
        }
        
        return result;
    }
    
    // Параллельное выполнение нескольких пайплайнов
    static async parallel(pipelines, input) {
        if (!Array.isArray(pipelines)) {
            throw new Error('pipelines должен быть массивом экземпляров AsyncPipeline');
        }
        
        const promises = pipelines.map((pipeline, index) => {
            return pipeline.execute(input)
                .then(result => ({ status: 'fulfilled', value: result, pipeline: index }))
                .catch(error => ({ status: 'rejected', reason: error, pipeline: index }));
        });
        
        const results = await Promise.all(promises);
        
        // Разделяем успешные и неудачные результаты
        const fulfilled = results.filter(r => r.status === 'fulfilled');
        const rejected = results.filter(r => r.status === 'rejected');
        
        return {
            all: results,
            fulfilled,
            rejected,
            success: rejected.length === 0
        };
    }
    
    // Статический метод для быстрого создания пайплайна
    static create() {
        return new AsyncPipeline();
    }
}

// Пример использования
const pipeline = new AsyncPipeline()
    .addStep(async (data) => {
        // Фильтрация: оставляем только положительные числа
        await new Promise(resolve => setTimeout(resolve, 50));
        return data.filter(x => x > 0);
    })
    .addStep(async (data) => {
        // Преобразование: умножаем на 2
        await new Promise(resolve => setTimeout(resolve, 50));
        return data.map(x => x * 2);
    })
    .addStep(async (data) => {
        // Агрегация: суммируем
        await new Promise(resolve => setTimeout(resolve, 50));
        return data.reduce((a, b) => a + b, 0);
    });

// Выполнение пайплайна
pipeline.execute([-1, 2, -3, 4, 5])
    .then(result => {
        console.log('Финальный результат пайплайна:', result);
    })
    .catch(error => {
        console.error('Ошибка выполнения пайплайна:', error);
    });

// Пример параллельного выполнения
const pipeline1 = AsyncPipeline.create()
    .addStep(async data => data.map(x => x + 1))
    .addStep(async data => data.filter(x => x % 2 === 0));

const pipeline2 = AsyncPipeline.create()
    .addStep(async data => data.map(x => x * 3))
    .addStep(async data => data.reduce((a, b) => a + b, 0));

AsyncPipeline.parallel([pipeline1, pipeline2], [1, 2, 3, 4, 5])
    .then(results => {
        console.log('Результаты параллельного выполнения:', results);
    });